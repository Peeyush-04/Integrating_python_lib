def reverse(ilist):
    return ilist[::-1];
def case_rev(str):
    return str.swapcase()