from setuptools import find_packages, setup


setup(
    name="firstlib",
    version="0.0.1",
    description="An id generator that generated various types and lengths ids",
    package_dir={"": "firstlib"},
    packages=find_packages(where="firstlib"),
    author="GGEZ",
    author_email="sethukumars774@gmail.com",
    classifiers=[
        "Programming Language :: Python :: 3.10",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.10",
)
